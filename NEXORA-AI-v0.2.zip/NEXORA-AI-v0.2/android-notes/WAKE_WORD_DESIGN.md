# NEXORA wake phrase — native Android design (not implemented in v0.2)

Desired phrases: “Hey Nexo”, “Hey Jarvis”, “Hello AI”.
Response: “At your service, sir. Directed by Mr. NIRMIT.”

A reliable implementation is not possible in a web page or ordinary PWA. It requires native Android work and platform-policy review.

Recommended staged approach:
1. Ship tap-to-talk first. It is supported in the web MVP.
2. Build a native Android app shell and add a user-controlled listening toggle.
3. If permitted for the app's distribution channel and device, evaluate an Android assistant/VoiceInteractionService integration. Do not assume a third-party app can silently claim system hotword detection.
4. If using a microphone foreground service, request runtime permission while the app is visible, show a persistent notification, clearly explain recording behavior, and provide an immediate stop control.
5. Run wake-word detection locally where possible; do not stream ambient audio to the server while waiting for a phrase.
6. After detecting the phrase, play the requested greeting and open a visible listening interface.
7. Keep tap-to-talk available if battery saver, OEM restrictions, permission revocation, reboot, or Android policy disables wake-word mode.

Hard limits:
- No app can respond while the phone is powered off.
- Android can restrict background microphone service starts and microphone access.
- The OS may reserve hotword activation for privileged/system assistant roles.
- Do not hide microphone use or record continuously without clear opt-in.
