# NEXORA AI v0.2 — working MVP foundation

**Brand:** NEXORA AI  
**Tagline:** Intelligence. Reimagined.  
**Credit:** Directed by Mr. NIRMIT

This is a development starter, not a finished commercial AI service. It provides a real backend structure and working starter flows for chat, accounts, SQLite cloud history, assistant profiles, basic saved memory, file/image/PDF input, web search, image generation, browser voice input/output, an admin view, and a coding scratchpad.

## Requirements
- Node.js 20+ and npm
- An OpenAI API key and an API model enabled for that key for AI features
- A parent/guardian should handle any API account, payment method, hosting purchase, or subscription setup.

## Run
1. Extract the ZIP.
2. Copy `.env.example` to `.env` in the project root.
3. Add a long random `JWT_SECRET`.
4. Add `OPENAI_API_KEY` and `OPENAI_MODEL` if you want live AI responses. Keep the key only in `.env`.
5. In the project folder run `npm install`, then `npm run dev`.
6. Open the Vite URL shown in the terminal (normally http://localhost:5173).

Without an API key, the UI and account/demo flows can be explored, but AI requests return a clear setup message.

## What's actually working in this starter
- Responsive web interface and PWA manifest/service worker.
- Email/password account registration and login (password hashes, signed tokens).
- SQLite-backed chat history, custom assistant instructions, and saved memory.
- Chat endpoint using OpenAI Responses API; optional web search tool.
- Image/PDF uploads are passed as supported input items to the model endpoint.
- Image generation endpoint using the OpenAI Images API.
- Browser speech recognition and speech synthesis where the browser supports them.
- Coding scratchpad (editor only; it does not execute code).
- Basic admin summary endpoint for the configured admin email.

## Not production-ready / still needs integration
- **Android APK:** this build is a PWA-ready web app, not a signed APK. Capacitor can wrap it after the web app is deployed/built; Android Studio or a cloud build service is needed to produce/sign the APK.
- **Wake word:** no hidden or always-on microphone recording is included. “Hey Nexo / Hey Jarvis / Hello AI” needs a separate native Android implementation, explicit microphone permission, visible foreground-service notification, opt-in, and testing. It cannot work when the phone is powered off. Android may block microphone foreground-service starts from the background.
- **Voice:** browser speech recognition is not ChatGPT-style low-latency realtime voice. Realtime audio requires a dedicated realtime provider integration.
- **Video generation:** provider adapter is intentionally not connected. Add an approved video model/provider and server-side job polling/storage.
- **Agents/automation:** assistant profiles and a basic task runner endpoint are foundations, not autonomous computer control. Add approval gates, audit logs, and per-tool permissions before real-world actions.
- **Subscriptions:** UI/API scaffolding only. Stripe or another billing provider, webhook verification, tax/legal review, and parental/guardian ownership are required before charging users.
- **Cloud deployment, Google sign-in, email verification, password reset, rate limiting, abuse monitoring, backups, file storage, and security review** remain before public launch.
- Admin access is restricted by `ADMIN_EMAIL`, but this is a minimal starter and needs stronger role management before launch.

## Main architecture
- `client/`: React + Vite + PWA interface.
- `server/`: Express API, SQLite, authentication, OpenAI adapter.
- Provider secrets stay on the server. The browser never receives API keys.
- Model IDs are configured through environment variables; available model names and features depend on the provider account.

## Android wake phrase plan
Use a native Android app with an explicit user-started listening mode and a persistent notification. Explore Android's `VoiceInteractionService`/assistant role only if the app qualifies and meets current platform and Play policy requirements. Do not promise wake-word support on every phone. A user-visible tap-to-talk fallback must always exist.
