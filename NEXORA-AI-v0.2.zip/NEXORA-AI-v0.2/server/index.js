import "dotenv/config";
import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import multer from "multer";
import OpenAI from "openai";
import { randomUUID } from "node:crypto";
import db from "./db.js";
import { signToken, requireAuth, requireAdmin } from "./auth.js";

const app = express();
const port = Number(process.env.PORT || 8787);
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(",") || true }));
app.use(express.json({ limit: "12mb" }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024, files: 4 } });
const openai = () => {
  if (!process.env.OPENAI_API_KEY || !process.env.OPENAI_MODEL) throw new Error("Configure OPENAI_API_KEY and OPENAI_MODEL in the server .env file.");
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
};
const models = () => (process.env.AVAILABLE_MODELS || process.env.OPENAI_MODEL || "").split(",").map(s => s.trim()).filter(Boolean);

app.get("/api/health", (_req,res) => res.json({ name:"NEXORA AI", version:"0.2.0", status:"online", aiConfigured:Boolean(process.env.OPENAI_API_KEY && process.env.OPENAI_MODEL), capabilities:["chat","accounts","history","assistants","memory","web-search","file-input","image-generation","browser-voice"] }));

app.post("/api/auth/register", async (req,res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || password.length < 10) return res.status(400).json({error:"Enter a valid email and a password of at least 10 characters."});
  try {
    const hash = await bcrypt.hash(password, 12);
    const role = process.env.ADMIN_EMAIL?.toLowerCase() === email ? "admin" : "user";
    const info = db.prepare("INSERT INTO users(email,password_hash,role) VALUES(?,?,?)").run(email,hash,role);
    const user = {id:Number(info.lastInsertRowid),email,role};
    res.json({token:signToken(user),user:{id:user.id,email:user.email,role:user.role}});
  } catch { res.status(409).json({error:"An account with that email may already exist."}); }
});
app.post("/api/auth/login", async (req,res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const row = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!row || !(await bcrypt.compare(String(req.body.password || ""), row.password_hash))) return res.status(401).json({error:"Email or password is incorrect."});
  res.json({token:signToken(row),user:{id:row.id,email:row.email,role:row.role}});
});
app.get("/api/me",requireAuth,(req,res)=>res.json({user:{id:req.user.sub,email:req.user.email,role:req.user.role}}));

app.get("/api/chats",requireAuth,(req,res)=>{
  const rows=db.prepare("SELECT id,title,updated_at FROM chats WHERE user_id=? ORDER BY updated_at DESC").all(req.user.sub);
  res.json({chats:rows});
});
app.get("/api/chats/:id",requireAuth,(req,res)=>{
  const row=db.prepare("SELECT * FROM chats WHERE id=? AND user_id=?").get(req.params.id,req.user.sub);
  if(!row) return res.status(404).json({error:"Chat not found."});
  res.json({chat:{...row,messages:JSON.parse(row.messages)}});
});
app.delete("/api/chats/:id",requireAuth,(req,res)=>{
  db.prepare("DELETE FROM chats WHERE id=? AND user_id=?").run(req.params.id,req.user.sub); res.json({ok:true});
});

app.get("/api/assistants",requireAuth,(req,res)=>res.json({assistants:db.prepare("SELECT id,name,instructions FROM assistants WHERE user_id=?").all(req.user.sub)}));
app.post("/api/assistants",requireAuth,(req,res)=>{
  const name=String(req.body.name||"").trim().slice(0,60), instructions=String(req.body.instructions||"").slice(0,3000);
  if(!name) return res.status(400).json({error:"Assistant name is required."});
  const id=randomUUID(); db.prepare("INSERT INTO assistants(id,user_id,name,instructions) VALUES(?,?,?,?)").run(id,req.user.sub,name,instructions);
  res.json({assistant:{id,name,instructions}});
});
app.get("/api/memory",requireAuth,(req,res)=>res.json({memories:db.prepare("SELECT id,content,created_at FROM memories WHERE user_id=? ORDER BY id DESC").all(req.user.sub)}));
app.post("/api/memory",requireAuth,(req,res)=>{
  const content=String(req.body.content||"").trim().slice(0,1000);
  if(!content) return res.status(400).json({error:"Memory cannot be empty."});
  db.prepare("INSERT INTO memories(user_id,content) VALUES(?,?)").run(req.user.sub,content); res.json({ok:true});
});
app.delete("/api/memory/:id",requireAuth,(req,res)=>{
  db.prepare("DELETE FROM memories WHERE id=? AND user_id=?").run(Number(req.params.id),req.user.sub); res.json({ok:true});
});

app.get("/api/models",requireAuth,(_req,res)=>res.json({models:models(),defaultModel:process.env.OPENAI_MODEL||""}));
app.post("/api/chat",requireAuth,upload.array("files",4),async(req,res)=>{
  try {
    const prompt=String(req.body.message||"").trim();
    if(!prompt && !(req.files||[]).length) return res.status(400).json({error:"Write a message or attach a file."});
    const model=String(req.body.model||process.env.OPENAI_MODEL||"");
    if(!model || !models().includes(model)) return res.status(400).json({error:"Choose a model configured by the server administrator."});
    const chatId=String(req.body.chatId||randomUUID());
    const previous=db.prepare("SELECT * FROM chats WHERE id=? AND user_id=?").get(chatId,req.user.sub);
    const messages=previous?JSON.parse(previous.messages):[];
    const assistantId=String(req.body.assistantId||"");
    const assistant=assistantId?db.prepare("SELECT * FROM assistants WHERE id=? AND user_id=?").get(assistantId,req.user.sub):null;
    const memories=db.prepare("SELECT content FROM memories WHERE user_id=? ORDER BY id DESC LIMIT 12").all(req.user.sub).map(x=>x.content);
    const instructions=[
      "You are NEXORA AI, a helpful, careful assistant. Be clear and accurate. If unsure, say so.",
      assistant?.instructions||"",
      memories.length ? "User-approved saved context (use only when relevant): "+memories.join("; ") : ""
    ].filter(Boolean).join("\n\n");
    const content=[{type:"input_text",text:prompt||"Please inspect the attached file(s) and explain their contents."}];
    for(const f of (req.files||[])){
      const mime=f.mimetype||"application/octet-stream";
      const data=`data:${mime};base64,${f.buffer.toString("base64")}`;
      if(mime.startsWith("image/")) content.push({type:"input_image",image_url:data});
      else if(mime==="application/pdf") content.push({type:"input_file",filename:f.originalname,file_data:data});
      else content.push({type:"input_text",text:`Attached file ${f.originalname} (${mime}) is not a supported visual/PDF input in this build.`});
    }
    const useSearch=req.body.webSearch==="true";
    const response=await openai().responses.create({
      model,
      instructions,
      input:[...messages.slice(-16),{role:"user",content}],
      ...(useSearch?{tools:[{type:"web_search"}]}:{})
    });
    const answer=response.output_text||"I couldn't produce a text response.";
    messages.push({role:"user",content:prompt||"[Attached file(s)]"},{role:"assistant",content:answer});
    const title=previous?.title||prompt.slice(0,64)||"New conversation";
    db.prepare(`INSERT INTO chats(id,user_id,title,messages,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET messages=excluded.messages,updated_at=CURRENT_TIMESTAMP`).run(chatId,req.user.sub,title,JSON.stringify(messages));
    res.json({chatId,answer,model,webSearch:useSearch});
  } catch(e){res.status(500).json({error:e.message||"AI request failed."});}
});

app.post("/api/images",requireAuth,async(req,res)=>{
  try {
    if(!process.env.OPENAI_API_KEY) throw new Error("Configure OPENAI_API_KEY on the server first.");
    const prompt=String(req.body.prompt||"").trim();
    if(!prompt) return res.status(400).json({error:"Describe the image you want."});
    const result=await openai().images.generate({model:"gpt-image-1",prompt,size:"1024x1024"});
    const b64=result.data?.[0]?.b64_json;
    if(!b64) throw new Error("The image provider returned no image.");
    res.json({image:`data:image/png;base64,${b64}`});
  }catch(e){res.status(500).json({error:e.message||"Image generation failed."});}
});

app.post("/api/tasks",requireAuth,(req,res)=>{
  const title=String(req.body.title||"").trim().slice(0,160);
  if(!title) return res.status(400).json({error:"Task title required."});
  const info=db.prepare("INSERT INTO tasks(user_id,title) VALUES(?,?)").run(req.user.sub,title);
  res.json({task:{id:Number(info.lastInsertRowid),title,status:"pending"}});
});
app.get("/api/tasks",requireAuth,(req,res)=>res.json({tasks:db.prepare("SELECT id,title,status,created_at FROM tasks WHERE user_id=? ORDER BY id DESC").all(req.user.sub)}));
app.patch("/api/tasks/:id",requireAuth,(req,res)=>{
  const status=req.body.status==="done"?"done":"pending";
  db.prepare("UPDATE tasks SET status=? WHERE id=? AND user_id=?").run(status,Number(req.params.id),req.user.sub);res.json({ok:true});
});

app.get("/api/admin/summary",requireAuth,requireAdmin,(_req,res)=>{
  res.json({
    users:db.prepare("SELECT COUNT(*) n FROM users").get().n,
    chats:db.prepare("SELECT COUNT(*) n FROM chats").get().n,
    assistants:db.prepare("SELECT COUNT(*) n FROM assistants").get().n,
    tasks:db.prepare("SELECT COUNT(*) n FROM tasks").get().n
  });
});

app.listen(port,()=>console.log(`NEXORA API listening on http://localhost:${port}`));
