NEXORA AI — GitHub Pages starter

UPLOAD:
1. Open https://github.com/sanjivaniarunpohane-bot/Nexora
2. Open the repository's main branch.
3. Upload index.html to the repository ROOT (not inside another folder).
4. Commit the change.
5. Open Settings > Pages.
6. Under Build and deployment, select Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait for the Pages deployment to finish in the Actions tab.

Your site URL:
https://sanjivaniarunpohane-bot.github.io/Nexora/

IMPORTANT:
This is a static landing page that GitHub Pages can host. It does not contain a running AI backend.
Live chat, accounts, cloud history, file processing, voice, image/video generation, subscriptions and agents need separately hosted server/API services.
